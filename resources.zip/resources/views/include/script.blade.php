	<!-- js -->
	<script src="{{URL::asset('assets/vendors/scripts/script.js')}}"></script>
